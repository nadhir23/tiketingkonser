@extends('layouts.main')

@section('container')
    <h1>Halaman About</h1>
@endsection
